package com.cg.entities;

public class Bus {
	private String busNumber;
	private BusRoute busRoute;
	private int totalSeats;
	private int fare;
}
