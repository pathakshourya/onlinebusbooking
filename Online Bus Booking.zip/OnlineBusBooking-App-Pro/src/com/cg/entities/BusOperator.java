package com.cg.entities;

import java.util.List;

public class BusOperator {

	private String busOperatorUsername;
	private String passowrd;
	private List<Bus> operationalBuses;
	private List<Integer> caseNumber; // Inorder to cancel bus or update bus route or fare
	
}
