package com.cg.entities;

public class FeedBack {
	private int rating;
	private String comment;
	private String username;
	private String routeName;
	private BusOperator busOperator; 
}
