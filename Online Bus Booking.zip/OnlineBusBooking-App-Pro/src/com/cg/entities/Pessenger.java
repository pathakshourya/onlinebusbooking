package com.cg.entities;

public class Pessenger {
	private String username;
	private String firstName;
	private String lastName;
	private long phoneNumber;
	private String email;
	private long identityDocNumber;
	private String identityDocumentName;
	
	
	
}
