package com.cg.entities;

import java.util.List;

public class AdminUser {
	private String adminUsername;
	private String password;
	private List<Integer> caseNumber; // bus operator's updation or bus cancelation request
	
}
