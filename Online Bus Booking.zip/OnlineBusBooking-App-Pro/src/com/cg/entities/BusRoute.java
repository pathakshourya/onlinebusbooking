package com.cg.entities;

public class BusRoute {
	private String routeName ; // unique
	private String source;
	private String destination;
}
