package com.cg.exceptions;

public class InvalidUsernameException extends Exception {

}
