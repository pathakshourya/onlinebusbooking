package com.cg.exceptions;

public class InvalidBookingIdException extends Exception {

}
