package com.cg.exceptions;

public class InvalidBusRouteNameException extends Exception {

}
