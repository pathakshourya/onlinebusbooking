package com.cg.exceptions;

public class InvalidDateException extends Exception {

}
